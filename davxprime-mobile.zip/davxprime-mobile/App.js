import { View, Text } from 'react-native';

export default function App() {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:'#0B0F14'}}>
      <Text style={{color:'white',fontSize:24}}>DavXPrime Demo</Text>
    </View>
  );
}
