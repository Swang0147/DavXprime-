# DavXPrime Mobile Demo

## Run in Termux
pkg update && pkg install nodejs git
npm install
npx expo start

## Build
npx eas-cli build -p android
